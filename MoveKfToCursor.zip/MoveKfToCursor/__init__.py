bl_info = {
    "name": "Keyframe To Cursor - with offset",
    "description": "Moves keyframe pos and value to cursor position with offset",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "support": "COMMUNITY",
    "category": "Animation"
}
import bpy

from .AddRemoveToPie import insert_to_pie,remove_from_pie
from . import Operator

def register():
    bpy.utils.register_class(Operator.MoveKeysToCursor_offset)
    insert_to_pie()
    print(f'{"":!<6}"Operator key to cursor(preserve offset) added"{"":!>6}')
    pass

def unregister():
    bpy.utils.unregister_class(Operator.MoveKeysToCursor_offset)
    remove_from_pie()
    print(f'{"":!<6}"Operator key to cursor(preserve offset) removed"{"":!>6}')
    pass