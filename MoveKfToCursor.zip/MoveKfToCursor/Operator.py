import bpy
import numpy as np

def move_kf_to_cursor():
    #n Define Global(for the function) variables
    keyToCursor_map = {}
    objs = bpy.context.selected_objects

    mode = bpy.context.mode
    selected_pose_boens = []
    if mode == 'POSE':
        for bone in bpy.context.selected_pose_bones:
            selected_pose_boens.append(bone.name)

    #n Loop through the selected objects and populate keyToCursor_map
    for obj in objs:
        keyToCursor_map[obj.name] = {}
        action = obj.animation_data.action
        keyToCursor_map[obj.name][action.name] = {}

        groups = action.groups
        for group in groups:
            keyToCursor_map[obj.name][action.name][group.name] = {}

            channels = group.channels
            for channel in channels:
                ch_name = str(channel.array_index) + "." + channel.data_path

                if channel.select:
                    if not channel.hide and not channel.lock:
                        keyToCursor_map[obj.name][action.name][group.name][ch_name] = []

                        keyframes = [keyframe for keyframe in channel.keyframe_points if keyframe.select_control_point]
                        for keyframe in keyframes:
                            keyToCursor_map[obj.name][action.name][group.name][ch_name].append(keyframe.co)

    if mode == 'POSE':
        for obj, actions in keyToCursor_map.items():
            for action, groups in actions.items():
                non_active_groups = [group for group, channels in keyToCursor_map[obj][action].items() if
                                     group not in selected_pose_boens]
                for group in non_active_groups:
                    del keyToCursor_map[obj][action][group]

    #n Find Graph Editor
    graph_editor = [spaces for area in bpy.context.screen.areas for spaces in area.spaces if
                    area.type == 'GRAPH_EDITOR']
    #n ReCreate graph editor's cursor x,y position - because cursor x returns 0 when not using .context
    cur_y = graph_editor[0].cursor_position_y
    cur_x = bpy.context.scene.frame_current
    #n Cursor
    cursor = (cur_x, cur_y)
    #n Loop Through Objects again and act only on if object,group,channel,keyframe is in keyToCursor_map
    for obj in objs:
        if obj.name in keyToCursor_map.keys():

            action = obj.animation_data.action
            if action.name in keyToCursor_map[obj.name].keys():

                groups = action.groups
                for group in groups:
                    if group.name in keyToCursor_map[obj.name][action.name].keys():

                        channels = group.channels
                        for channel in channels:
                            ch_name = str(channel.array_index) + "." + channel.data_path

                            #n If channel is in keyToCursor_map take the keyframe position and split it in `x` and `y`
                            if ch_name in keyToCursor_map[obj.name][action.name][group.name].keys():
                                mKeyframes = keyToCursor_map[obj.name][action.name][group.name][ch_name]
                                mKeyframes_x_pos = [keyframe.x for keyframe in mKeyframes]
                                mKeyframes_y_pos = [keyframe.y for keyframe in mKeyframes]
                                #n Check if channel is rotation. If it is then keyframe Y value has to be converted from degrees to radians
                                if channel.data_path.split(".")[-1] == 'rotation_euler':
                                    distance = (cursor[0] - mKeyframes_x_pos[0], cursor[1] - np.rad2deg(mKeyframes_y_pos[0]))
                                    #n Create new X and Y pos lists
                                    newKeyframe_x_pos = np.array(mKeyframes_x_pos) + distance[0]
                                    newKeyframe_y_pos = np.array(mKeyframes_y_pos) + np.deg2rad(distance[1])#n we convert the distance back to radians

                                #n If it is not a rotation channel, do straight forward math
                                else:
                                    distance = (cursor[0] - mKeyframes_x_pos[0], cursor[1] - mKeyframes_y_pos[0])
                                    #n Create new X and Y pos lists
                                    newKeyframe_x_pos = np.array(mKeyframes_x_pos) + distance[0]
                                    newKeyframe_y_pos = np.array(mKeyframes_y_pos) + distance[1]

                                #n Itterate through keyframes of the channe and give them X,Y values from the newX and newY lists respectively
                                keyframes = channel.keyframe_points
                                for keyframe in keyframes:
                                    if keyframe.co.x in mKeyframes_x_pos:
                                        keyf_id = mKeyframes_x_pos.index(keyframe.co.x)
                                        keyframe.co.x = newKeyframe_x_pos[keyf_id]
                                        keyframe.co.y = newKeyframe_y_pos[keyf_id]

    #n Loop once more to update fcurves(fix handles)
    for obj in objs:
        if obj.name in keyToCursor_map.keys():
            action = obj.animation_data.action
            if action.name in keyToCursor_map[obj.name].keys():
                groups = action.groups
                for group in groups:
                    if group.name in keyToCursor_map[obj.name][action.name].keys():
                        channels = group.channels
                        for channel in channels:
                            channel.update()


class MoveKeysToCursor_offset(bpy.types.Operator):
    bl_idname = "graph.snap_offset"
    bl_label = "Move Keys To Cursor(preserveOffset)"
    def execute(self,context):
        move_kf_to_cursor()
        return{'FINISHED'}
