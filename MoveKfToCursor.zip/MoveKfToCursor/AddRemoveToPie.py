
import bpy,pathlib,sys

def insert_to_pie():
    '''
    Writes the Operator to the Graph Editor Pie Menu every time the 'addon' is activated(registered).
    Makes sure if the Operator is added to the file, it will not be added again.
    If the Operator is not in the file(the file is in it's original form) it will save the file to
    ./backup/ if something goes wrong and the file get's corrupted.
    '''
    #n Find the file path
    filename = 'space_graph.py'
    a = sys.executable.split("\\")[:-1]
    b = bpy.app.version_string.split()[0]
    graph_editor_filepath = "\\".join(a) + '\\' + b + '\\scripts\\startup\\bl_ui\\' + filename

    #n Prepare for file data and it's analysis
    data = []
    line_of_interest = 'pie.operator("graph.snap", text="Flatten Handles").type = '
    new_line = '        pie.operator("graph.snap_offset", text="To Cursor(preserve offset)")\n'
    with open(graph_editor_filepath,'r') as file:
        for line in file.readlines():
            data.append(line)
    new_line_in_file = False    #trigger to find if the operator is already added to the file
    #n Loop through the data to find the last line of the Snap Pie Menu, so we can add our operator after it
    data_index = 0
    for line in data:
        if new_line in line:
            new_line_in_file = True
        else:
            if line_of_interest in line:
                data_index = data.index(line)

    #n Once we found it we split the data in to two and insert our operator between the two parts
    new_data_partA = data[:data_index+1]
    insert = new_line
    new_data_partB = data[data_index+1:]

    #n We check if our Operator is added to the pie menu,if it is not -add it, if it is - do nothing
    if not new_line_in_file:
        a = str(pathlib.Path(__file__).parent)
        #n Our backup
        with open(f'{a}/backup/{filename}','w+') as file:
            for line in data:
                file.write(line)
        #n new file string
        modified_file_string = "".join(new_data_partA) + insert + "".join(new_data_partB)
        #n push new file string to Graph editor file(deleting the old and adding the new)
        with open(graph_editor_filepath,'w') as file:
            file.write(modified_file_string)
    else:
        pass



def remove_from_pie():
    '''
    Removes our Operator from the Snap Pie Menu once our 'addon' was removed
    '''
    filename = 'space_graph.py'
    a = sys.executable.split("\\")[:-1]
    b = bpy.app.version_string.split()[0]
    graph_editor_filepath = "\\".join(a) + '\\' + b + '\\scripts\\startup\\bl_ui\\' + filename

    data = []
    line_of_interest = 'pie.operator("graph.snap_offset", text="To Cursor(preserve offset)")'
    with open(graph_editor_filepath, 'r') as file:
        for line in file.readlines():
            if line_of_interest in line:
                pass
            else:
                data.append(line)

    with open(graph_editor_filepath,"w+") as file:
        file.write("".join(data))

