bl_info = {
    "name": "Viewport Render GP keyframes",
    "description": "Vieport rendering of all GP keyframes",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "support": "COMMUNITY",
    "category": "Animation"
}
import bpy

from .AddToViewDropdown import insert_in_view_dropdown,remove_from_view_dropdown
from . import Operator


def register():
    bpy.utils.register_class(Operator.RenderGPKeyframes)
    insert_in_view_dropdown()
    print(f'{"":!<6}\033[1;40;92m"Operator Viewport Render GP Keyframes added"\033[0m{"":!>6}')
    pass

def unregister():
    bpy.utils.unregister_class(Operator.RenderGPKeyframes)
    remove_from_view_dropdown()
    print(f'{"":!<6}\033[1;40;92m"Operator Viewport Render GP Keyframes removed"\033[0m{"":!>6}')
    pass