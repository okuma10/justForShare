
import bpy
import re

def render_GP_keyframes():


    frame_numbers = set()
    desired_render_formats = ['JPEG','PNG']

    # Init
    context = bpy.context.area.type
    bpy.context.area.type = "VIEW_3D"
    init_render_format = bpy.context.scene.render.image_settings.file_format


    #   Grease Pencil Data
    for pencil in bpy.data.grease_pencils:
        for layer in pencil.layers:
            for frame in layer.frames:
                frame_numbers.add(frame.frame_number)
    frame_numbers = sorted(list(frame_numbers))

    

    #   Get File paths
    render_path = bpy.context.scene.render.filepath
    opened_file_path = bpy.data.filepath
    #   Populate Scene Name 
    scene_name = ""
    if len(opened_file_path)>0:
        find_file_name = re.search(r'\S\\.*\\(.*).blend$',opened_file_path)
        scene_name = find_file_name[0].split('.')[0].split('\\')[-1]
    else:
        scene_name = "Untitled"



    #   Check for format
    render_format = init_render_format
    if render_format in desired_render_formats:
        pass
    else:
        bpy.context.scene.render.image_settings.file_format = 'PNG'



    #   Main
    for frame in frame_numbers:
        print(f'\033[42;30mRendering Frame: {frame}')
        bpy.context.scene.frame_set(frame)
        bpy.context.scene.render.filepath = render_path +scene_name+ str(f'_{frame:0>5}')
        # print(f'{"":<3}at:{bpy.context.scene.render.filepath}')
        bpy.ops.render.opengl(animation=False, sequencer=False, write_still=True, view_context=True)
        # bpy.ops.render.render(write_still = True, use_viewport = True)



    #   Restore -Print color, context, render_path name, file format
    print('Render Complete\033[0m')
    bpy.context.area.type = context
    bpy.context.scene.render.filepath = render_path
    bpy.context.scene.render.image_settings.file_format = init_render_format



class RenderGPKeyframes(bpy.types.Operator):
    bl_idname = "render.render_gp_keyframes"
    bl_label = "Render only Grease Pencil keyframes"
    def execute(self,context):
        render_GP_keyframes()
        return{'FINISHED'}

